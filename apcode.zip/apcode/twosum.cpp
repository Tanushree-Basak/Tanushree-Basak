class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        map<int, int> sumMap;
        
        for (int i = 0; i < nums.size(); i++) {
            int remaining = target - nums[i];  
            
            if (sumMap.find(remaining) != sumMap.end()) {  
                return {sumMap[remaining], i};  
            }
            
            sumMap[nums[i]] = i;  
        }
        
        return {};  
    }
};
